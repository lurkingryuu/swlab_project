import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:app/screens/functions.dart';
import 'package:app/screens/student_course_analysis.dart';

class TeacherCoursePage extends StatefulWidget {
  const TeacherCoursePage({super.key, required this.id, required this.name});
  final String id;
  final String name;
  @override
  State<TeacherCoursePage> createState() => _TeacherCoursePageState();
}

class _TeacherCoursePageState extends State<TeacherCoursePage> {
  final TextEditingController _controller = TextEditingController();
  List<Map> StudentList = [
    {'Name': 'Vonteri Varshith Reddy', 'Id': '21CS10081'},
    {'Name': 'Yelisetty Karthikey S M', 'Id': '21CS30060'},
    {'Name': 'Thota Kesava Chandra', 'Id': '21CS30056'}
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
          // child: the name passed from the previous page
          child: Text(widget.name),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
              children: <Widget>[
                const SizedBox(height:25),
                ElevatedButton(
                  onPressed: () async {
                    Map res = await StartAttendance(widget.id);
                    Fluttertoast.showToast(
                        msg: res['message'],
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        timeInSecForIosWeb: 1,
                        backgroundColor: (res['status'] == 200)? Colors.green : Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                  ),
                  child: const Text(
                    "Start Attendance",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(height:25),
                ElevatedButton(
                  onPressed: () async {
                    Map res = await EndAttendance(widget.id);
                    Fluttertoast.showToast(
                        msg: res['message'],
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.BOTTOM,
                        timeInSecForIosWeb: 1,
                        backgroundColor: (res['status'] == 200)? Colors.green : Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                  ),
                  child: const Text(
                    "End Attendance",
                    style: TextStyle(color: Colors.white),
                  ),
                ),
                const SizedBox(
                  height : 80,
                  child: ListTile(
                    title: Text("Total Registered Students"),
                    subtitle: Text('3'),
                  ),
                ),
                const SizedBox(
                  height : 80,
                  child: ListTile(
                    title: Text("Total Classes"),
                    subtitle: Text('3'),
                  ),
                ),
                SizedBox(
                  height : (StudentList.length)*80.0,
                  child:ListView.builder(
                    itemCount: StudentList.length,
                    itemBuilder: (context, index) {
                      return SizedBox(
                          height : 80,
                          child : ListTile(
                            title: Text(StudentList[index]['Name']),
                            subtitle: Text(StudentList[index]['Id']),
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => StudentCourseAnalysis(
                                          sid: StudentList[index]['Id'],
                                          cid: widget.id,
                                          name: StudentList[index]['Name'],
                                      )
                                  )
                              );
                            },
                          )
                      );
                    },
                  ),
                ),
              ]
          ),
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }





}
