
class Utils{
  //you add your port no that u define in node js
  static String baseUrl="http://10.145.215.210:3000"; // here we define the base url
  // static String baseUrl="https://bit-rebels-api.onrender.com"; // here we define the base url
}
